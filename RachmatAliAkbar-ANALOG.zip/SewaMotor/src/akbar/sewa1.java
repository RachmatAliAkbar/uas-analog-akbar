package akbar;
public class sewa1 {
	String noKtp;
	String nama;
	String alamat;
	String mk;
	String lma;
	String tanggal;
	String harga;
	
	public sewa1 (String noKtp, String nama, String alamat, String mk, String lma, String tanggal, String harga) {

		this.noKtp = noKtp;
		this.nama = nama;
		this.alamat = alamat;
		this.mk = mk;
		this.lma = lma;
		this.tanggal = tanggal;
		this.harga = harga;
	
}
}
package akbar;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Color;

public class sewa {

	private JFrame frmPenyewaanMotorAkbar;
	private JTextField nm;
	private JTextField at;
	private JTextField no;
	private JTextField tgl;
	private JTextArea textArea;
	double harga;
	int harga1;
	double hargam;
	int hargal;
	ArrayList<sewa1> sewalist = new ArrayList<sewa1>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sewa window = new sewa();
					window.frmPenyewaanMotorAkbar.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public sewa() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPenyewaanMotorAkbar = new JFrame();
		frmPenyewaanMotorAkbar.setTitle("Penyewaan Motor Akbar");
		frmPenyewaanMotorAkbar.getContentPane().setBackground(new Color(250, 128, 114));
		frmPenyewaanMotorAkbar.setBounds(100, 100, 712, 424);
		frmPenyewaanMotorAkbar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPenyewaanMotorAkbar.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(250, 235, 215));
		panel.setBounds(10, 11, 332, 155);
		frmPenyewaanMotorAkbar.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Data Diri");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(127, 11, 80, 14);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Nama");
		lblNewLabel_1.setBounds(10, 78, 46, 14);
		panel.add(lblNewLabel_1);

		nm = new JTextField();
		nm.setBounds(82, 75, 220, 20);
		panel.add(nm);
		nm.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("Alamat");
		lblNewLabel_1_1.setBounds(10, 109, 46, 14);
		panel.add(lblNewLabel_1_1);

		at = new JTextField();
		at.setColumns(10);
		at.setBounds(82, 106, 220, 20);
		panel.add(at);

		JLabel lblNewLabel_1_1_1 = new JLabel("");
		lblNewLabel_1_1_1.setBounds(10, 109, 46, 14);
		panel.add(lblNewLabel_1_1_1);

		no = new JTextField();
		no.setColumns(10);
		no.setBounds(82, 44, 220, 20);
		panel.add(no);

		JLabel lblNewLabel_1_2 = new JLabel("No KTP");
		lblNewLabel_1_2.setBounds(10, 47, 46, 14);
		panel.add(lblNewLabel_1_2);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(250, 235, 215));
		panel_2.setBounds(10, 170, 332, 155);
		frmPenyewaanMotorAkbar.getContentPane().add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("Merk Motor");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 44, 74, 14);
		panel_2.add(lblNewLabel_2);

		JComboBox merk = new JComboBox();
		merk.setModel(new DefaultComboBoxModel(new String[] { "", "VARIO", "BEAT", "NMAX" }));
		merk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (merk.getSelectedItem() == "VARIO") {
					hargam = 1.5;
				}
				if (merk.getSelectedItem() == "BEAT") {
					hargam = 1;
				}
				if (merk.getSelectedItem() == "NMAX") {
					hargam = 2;
				}
			}
		});
		merk.setMaximumRowCount(4);
		merk.setBounds(104, 40, 100, 22);
		panel_2.add(merk);

		JLabel lblNewLabel_2_1 = new JLabel("Penyewaan");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBounds(0, 80, 74, 14);
		panel_2.add(lblNewLabel_2_1);

		JComboBox lama = new JComboBox();
		lama.setModel(new DefaultComboBoxModel(new String[] { "", "PERHARI", "PERMINGGU" }));
		lama.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (lama.getSelectedItem() == "PERHARI") {
					hargal = 50000;
				}
				if (lama.getSelectedItem() == "PERMINGGU") {
					hargal = 250000;
				}
			}
		});
		lama.setMaximumRowCount(3);
		lama.setBounds(104, 76, 100, 22);
		panel_2.add(lama);

		JLabel lblNewLabel_2_1_1 = new JLabel("Tanggal");
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setBounds(0, 109, 74, 14);
		panel_2.add(lblNewLabel_2_1_1);

		JLabel lblNewLabel_2_1_1_1 = new JLabel("Penyewaan");
		lblNewLabel_2_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1_1.setBounds(0, 127, 74, 14);
		panel_2.add(lblNewLabel_2_1_1_1);

		tgl = new JTextField();
		tgl.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tgl.setColumns(10);
		tgl.setBounds(104, 109, 100, 32);
		panel_2.add(tgl);

		JLabel lblDataSewa = new JLabel("Data Sewa");
		lblDataSewa.setHorizontalAlignment(SwingConstants.CENTER);
		lblDataSewa.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDataSewa.setBounds(124, 11, 83, 14);
		panel_2.add(lblDataSewa);
		System.out.println();

		JButton rst = new JButton("Reset");
		rst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				no.setText(null);
				nm.setText(null);
				at.setText(null);
				merk.setSelectedItem(null);
				lama.setSelectedItem(null);
				tgl.setText(null);
			}
		});
		rst.setBounds(253, 336, 89, 36);
		frmPenyewaanMotorAkbar.getContentPane().add(rst);

		JButton sewa = new JButton("Sewa");
		sewa.setBounds(10, 336, 89, 36);
		frmPenyewaanMotorAkbar.getContentPane().add(sewa);

		JButton hps = new JButton("Hapus");
		hps.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText(null);
			}
		});
		hps.setBounds(127, 336, 89, 36);
		frmPenyewaanMotorAkbar.getContentPane().add(hps);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(352, 11, 334, 314);
		frmPenyewaanMotorAkbar.getContentPane().add(scrollPane);

		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);

		sewa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String noKtp = no.getText();
				String nama = nm.getText();
				String alamat = at.getText();
				String mk = merk.getSelectedItem().toString();
				String lma = lama.getSelectedItem().toString();
				String tanggal = tgl.getText();
				double hargat = hargam * hargal;
				String hg = String.valueOf(hargat);

				sewa1 p = (new sewa1(noKtp, nama, alamat, mk, lma, tanggal, hg));
				sewalist.add(p);
				String t = "";
				for (int i = 0; i < sewalist.size(); i++) {
					t = ("========================================================" + "\n + No KTP : "
							+ sewalist.get(i).noKtp + "\n + Nama : " + sewalist.get(i).nama + "\n + Alamat : "
							+ sewalist.get(i).alamat + "\n + Merk Motor : " + sewalist.get(i).mk + "\n + Lama Sewa : "
							+ sewalist.get(i).lma + "\n + Tanggal Sewa : " + sewalist.get(i).tanggal
							+ "\n + Harga Sewa : Rp." + sewalist.get(i).harga + "\n");
				}
				textArea.append(t);
			}
		});
	}
}
